package test.service;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.List;


public class TestService{

    public static void main(String[] args) throws Exception{

        String urlServer="http://localhost:8082/Clase10";
        
        
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Clientes");
        System.out.println(getBody(urlServer+"/resources/clientes/v1"));
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Clientes Alta Error de Parametros");
        System.out.println(getBody(urlServer+"/resources/clientes/v1/alta?nombre=Jeronimo&apellido=Garcia&tipoCliente=VIP"));
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Clientes Alta Error de Parametros");
        System.out.println(getBody(urlServer+"/resources/clientes/v1/alta?nombre=Jeronimo&tipoCliente=MINORISTA"));
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Clientes Alta OK");
        System.out.println(getBody(urlServer+"/resources/clientes/v1/alta?nombre=Jeronimo&apellido=Garcia&tipoCliente=MINORISTA"));
        System.out.println("****************************************************");
        System.out.println("- clientes All");
        Type ListType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente> list=new Gson().fromJson(getBody(urlServer+"/resources/clientes/v1/all"), ListType);
        list.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("- clientes LikeApellido fer");
        list=new Gson().fromJson(getBody(urlServer+"/resources/clientes/v1/likeApellido?apellido=fer"), ListType);
        list.forEach(System.out::println);
        System.out.println("****************************************************");
        
        
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Articulos");
        System.out.println(getBody(urlServer+"/resources/articulos/v1"));
        System.out.println("****************************************************");
        System.out.println("- Test Servicio Articulos Alta");
        System.out.println(getBody(urlServer+"/resources/articulos/v1/alta?id=611&descripcion=TV41&precio=10000"));
        
        
        System.out.println("****************************************************");
        System.out.println("- Articulo All");
        ListType=new TypeToken<List<Articulo>>(){}.getType();
        List<Articulo> list2=new Gson().fromJson(getBody(urlServer+"/resources/articulos/v1/all"), ListType);
        list2.forEach(System.out::println);
        
        System.out.println("****************************************************");
        System.out.println("- Articulo LikeArticulo");
        list2=new Gson().fromJson(getBody(urlServer+"/resources/articulos/v1/likeDescripcion?descripcion=la"), ListType);
        list2.forEach(System.out::println);
        

        
        
    }

    public static String getBody(String url) throws Exception{
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        response.headers().map().forEach((k,v)->System.out.println("Key: "+k+" - value: "+v));
        return response.body();
    }
    
}

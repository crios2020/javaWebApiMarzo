package ar.com.eduit.curso.java.web.rs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("test")
public class TestServicio {
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String info(){
        return "<h1>hola WS REST</h1>";
    }
    
    @GET
    @Path("info2")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "Hoy es Martes";
    }
    
    @GET
    @Path("calculadora")
    @Produces(MediaType.TEXT_PLAIN)
    public String calculadora(@QueryParam("nro1") int nro1, @QueryParam("nro2") int nro2){
        return (nro1+nro2)+"";
    }
    
}
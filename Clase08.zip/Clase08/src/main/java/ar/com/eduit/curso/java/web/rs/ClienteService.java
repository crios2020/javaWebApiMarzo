package ar.com.eduit.curso.java.web.rs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("clientes/v1")
public class ClienteService {
    @GET
    public String info(){
        return "Servicio Articulos Activo";
    }
}
package ar.com.eduit.curso.java.web.rs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("articulos/v1")
public class ArticuloService {
    
    @GET
    public String info(){
        return "Servicio Articulos Activo";
    }
}
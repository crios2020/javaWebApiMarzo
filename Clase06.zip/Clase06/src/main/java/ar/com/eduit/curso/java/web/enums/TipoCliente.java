package ar.com.eduit.curso.java.web.enums;

public enum TipoCliente { MINORISTA,MAYORISTA,EMPRESA }
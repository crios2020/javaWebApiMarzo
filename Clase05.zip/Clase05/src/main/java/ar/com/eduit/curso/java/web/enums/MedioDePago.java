package ar.com.eduit.curso.java.web.enums;

public enum MedioDePago { EFECTIVO,DEPOSITO,TARJETA,DEBITO,MERCADOPAGO }
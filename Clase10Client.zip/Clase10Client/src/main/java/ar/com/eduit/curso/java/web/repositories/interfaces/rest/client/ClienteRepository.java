package ar.com.eduit.curso.java.web.repositories.interfaces.rest.client;

import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.edut.curso.java.web.utils.hhtp.HttpBody;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{

    //"http://localhost:8082/Clase10/resources"
    private String urlServer;

    public ClienteRepository(String urlServer) {
        this.urlServer = urlServer;
    }
    
    @Override
    public void save(Cliente cliente) {
        String url=urlServer+"/clientes/v1/alta?nombre="+cliente.getNombre()
                +"&apellido="+cliente.getApellido()+"&tipoCliente="+cliente.getTipoCliente();
        try{
            String response=HttpBody.getBody(url);
            cliente.setId(Integer.parseInt(response));
        }catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void remove(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cliente> getAll() {
        String url=urlServer+"/clientes/v1/all";
        String response=HttpBody.getBody(url);
        Type ListType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente> list=new Gson().fromJson(response, ListType);
        return list;
    }

    @Override
    public List<Cliente> getLikeApellido(String apellido) {
        String url=urlServer+"/clientes/v1/likeApellido?apellido="+apellido;
        String response=HttpBody.getBody(url);
        Type ListType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente> list=new Gson().fromJson(response, ListType);
        return list;
    }

}
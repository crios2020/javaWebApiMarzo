package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoCliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.rest.client.ClienteRepository;

public class TestServiceRepository {
    public static void main(String[] args) {
        String url="http://localhost:8082/Clase10/resources";
        
        I_ClienteRepository cr=new ClienteRepository(url);
        Cliente cliente=new Cliente("Gabriel", "Moretti", TipoCliente.MINORISTA);
        cr.save(cliente);
        System.out.println(cliente);
        System.out.println("**************************************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("**************************************************");
        cr.getLikeApellido("Gui").forEach(System.out::println);
   
        
        
        
    }
}
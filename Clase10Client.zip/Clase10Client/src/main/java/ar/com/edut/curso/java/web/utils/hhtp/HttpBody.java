package ar.com.edut.curso.java.web.utils.hhtp;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpBody {
    public static String getBody(String url){
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
        try{
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            //response.headers().map().forEach((k,v)->System.out.println("Key: "+k+" - value: "+v));
            return response.body();
        }catch(Exception e){
            System.out.println(e);
            return "";
        }
    }
}